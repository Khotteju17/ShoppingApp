//
//  WebService.swift
//  Shopping App
//
//  Created by Tejashree on 21/05/23.
//

import SystemConfiguration
import Foundation
import SwiftyJSON
import Alamofire

class WebService {
    func loadItems( onCompletion: @escaping ([ProductData]) -> ()) {
        
        var productData = [ProductData]()
        
        let shoppingURL = URL(string: "https://dummyjson.com/products")!
        
        let _ = URLSession.shared.dataTask(with: shoppingURL) { (data, response, error) in
            
            print("Data error: \(data)")
            print("Data error: \(response)")
            guard error == nil else {
                print("error while fetching the data: \(String(describing: error?.localizedDescription))")
                return
            }
            
            guard let fetchedData = data else {
                print("NO Data received for the specified URL")
                return
            }
            
            guard let dictionary = try? JSONSerialization.jsonObject(with: fetchedData, options: JSONSerialization.ReadingOptions.allowFragments) as? [String: Any] else {
                
                print("Data error: \(fetchedData)")
                return
            }
            
            guard dictionary["status_code"] != nil else {
                let itemsDictionary = dictionary["products"] as! [[String: Any]]
                
                //                    productData = itemsDictionary.compactMap(ProductData.init)
                //                } else {
                //                    for item in itemsDictionary.compactMap(ProductData.init) {
                //                                        productData.append(item)
                //                                    }
                if !itemsDictionary.isEmpty{
                    
                    itemsDictionary.forEach { (pro) in
                        let cue = ProductData()
                        if let title = pro["title"]{
                            cue.title = title as! String
                        }
                        if let description = pro["description"]{
                            cue.description = description as! String
                        }
                        
                        if let price = pro["price"]{
                            cue.price = String(price as! Double)
                        }
                        if let discountPercentage = pro["discountPercentage"]{
                            cue.discountPercentage = String(discountPercentage  as! Double)
                        }
                        if let rating = pro["rating"]{
                            cue.rating = String(rating as! Double)
                        }
                        
                        if let stock = pro["stock"]{
                            cue.stock = String(stock  as! Int)
                        }
                        if let brand = pro["brand"]{
                            cue.brand = brand as! String
                        }
                        if let category = pro["category"]{
                            cue.category = category as! String
                        }
                        
                        
                        if let thumbnail = pro["thumbnail"]{
                            cue.thumbnail = thumbnail as! String
                        }
                        if let images = pro["images"]{
                            //                            cue.images = [images] as! [String]
                        }
                        productData.append(cue)
                    }
                }
                
                
                DispatchQueue.main.async {
                    onCompletion(productData)
                }
                
                return
            }
            
            
            
            
        }.resume()
    }
}

// MARK: - Class Product Data

class ProductData: Codable{
    var title = ""
    var description = ""
    var price = ""
    var discountPercentage = "";
    var rating = "";
    var stock = ""
    var brand = ""
    var category = ""
    var thumbnail = ""
    var images = [String]()
    init(){
    }
    init(title: String, description: String, price: String, discountPercentage: String, rating: String, stock:String, brand:String, category:String,thumbnail:String,images:[String]) {
        self.title = title
        self.description = description
        self.price = price
        self.discountPercentage = discountPercentage
        self.rating = rating
        self.stock = stock
        self.brand = brand
        self.category = category
        self.thumbnail = thumbnail
        self.images = images
    }
    
    init?(dictionary: [String: Any]) {
        
        guard let title = dictionary["title"] as? String,
              let description = dictionary["description"] as? String,
              let price = dictionary["price"] as? String,
              let brand = dictionary["brand"] as? String ,
              let images = dictionary["images"] as? [String] else{
            return nil
        }
        
        self.title = title
        self.description = description
        self.price = price
        self.brand = brand
        self.images = images
    }
}
// MARK: - Class Product Data List
class ProductDataListViewModel {
    
    var productDataListViewModel: [ProductViewModel] = [ProductViewModel]()
    private var webService: WebService
    private var pageNumber = 0
    private var completion: ()->() = {  }
    
    init(webService: WebService, completion: @escaping () -> ()) {
        self.webService = webService
        self.completion = completion
        populateproducts()
    }
    
    func populateproducts() {
        
        if pageNumber <= MAX_PAGE {
            pageNumber += 1
        }
        
        webService.loadItems() { (productdata) in
            
            if self.productDataListViewModel.isEmpty {
                self.productDataListViewModel = productdata.map(ProductViewModel.init)
            } else {
                for product in productdata {
                    self.productDataListViewModel.append(ProductViewModel.init(product))
                }
            }
            
            self.completion()
        }
    }
    
    func productAt(index: Int) -> ProductViewModel {
        return self.productDataListViewModel[index]
    }
    
}

// MARK: - Product View

class ProductViewModel {
    
    var title: String!
    var rating: String!
    var brand: String!
    var price: String!
    var category : String!
    var description : String!
    var thumbnail : String!
    var image: [String]!
    
    init(_ product: ProductData) {
        
        self.title = product.title
        self.rating = product.rating
        self.brand = product.brand
        self.price = product.price
        self.thumbnail = product.thumbnail
        self.image = product.images
        self.category = product.category
        self.description = product.description
    }
    init(){}
}

