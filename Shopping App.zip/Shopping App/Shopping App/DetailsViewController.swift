//
//  DetailsViewController.swift
//  Shopping App
//
//  Created by Tejashree on 22/05/23.
//

import Foundation
import UIKit
import Kingfisher

class DetailsViewController: UIViewController {
    static var identifier = "DetailsViewController"
    @IBOutlet weak var imageview: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var ratingLabel: UILabel!
    @IBOutlet weak var categoryLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    var selectedProduct = ProductViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.bindData()
    }
    func bindData(){
        
        titleLabel.text = selectedProduct.title
        titleLabel.textAlignment = .center
        priceLabel.text = "Price - ₹ " + selectedProduct.price
        ratingLabel.text = "Rating - " + selectedProduct.rating + "*"
        categoryLabel.text = "Category - " + selectedProduct.category
        descriptionLabel.text = "Description - " + selectedProduct.description
        
        imageview.layer.borderWidth = 1
        imageview.layer.borderColor = UIColor.gray.cgColor
        let resource = ImageResource(downloadURL: URL(string: selectedProduct.thumbnail)!, cacheKey: selectedProduct.thumbnail)
        imageview.kf.setImage(with: resource)
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    // MARK: - IBAction
    @IBAction func closeButtonTapped(){
        navigationController?.popViewController(animated: true)
        
        dismiss(animated: true, completion: nil)
    }
    
}
